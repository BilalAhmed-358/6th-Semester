# Proxy-Server-With-Cache-and-Block-list

This is a proxy server that can store any http and https website in the cache of the server. Block list to block any of the website is also implemented.

To run the code follow this command:

```
python cache_server.py 8000
```

Now go to the browser and type:

```
localhost:8000/(Website)
````
Example:
```
localhost:8000/google.com
```
