import socket as s
import os

sock = s.socket()
portNo = 3000
print(os.getcwd())
os.chdir("../")
dir = os.getcwd()
f = open(dir + "/hostname.txt", "r")
hostName = f.read()
print(hostName)
sock.connect((hostName, portNo))
print("\nConnections Successful!!\n\n")

print("\n\nPress 0 anytime to break connection!!\n\n")

while 1:
    m = sock.recv(1024)
    m = m.decode()
    print("Server: ", m)
    if m == "0":
        break 

    message = str(input("..."))
    if message == "0":
        break
    mes = message.encode()
    if sock.send(mes):
        print("Message Sent sucessful!!")
    else:
        print("Some error occured!!")