import socket as s


hostName = s.gethostname()
portNo = 3000
print("Server running at: ", hostName, " & Port No: ", portNo)
f = open("hostname.txt", "w")
f.write(hostName)
f.close()
sock = s.socket()
sock.bind((hostName, portNo))
print("")
print("\nSocket has been bound!!\n\n")
sock.listen(1)
print("Server Listening at: ", hostName, " & Port No: ", portNo)
print("\n\nWaiting for client connection!!")
connecton, address = sock.accept()
print("\n\nConnection Successful at ", address)
print("\n\nPress 0 anytime to break connection!!\n\n")

while 1:
    message = str(input("..."))
    mes = message.encode()
    if mes == "0":
        break
    if connecton.send(mes):
        print("Message Sent sucessful!!")
    else:
        print("Some error occured!!")

    m = connecton.recv(1024)
    m = m.decode()
    print("Client: ", m)
    if m == "0":
        break