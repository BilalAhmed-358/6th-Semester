import socket as s
from time import sleep
import threading
import sys

client_list = []

def delivered_message(client, addr):
    while True:
        try:
            reply = client.recv(1024).decode()
            reply = str(addr) + " : " + str(reply)
            print(reply)
            deliver_message(reply, sender=client)
        except:
            reply = str(addr) + " : Left"
            print(reply)
            deliver_message(reply, sender=client)
            client_list.remove(client)
            sys.exit()


def deliver_message(msg, sender=None):
    print("delivering message : " + msg)
    for client in client_list:
        if sender is not client:
            print("Just delivered Message")
            client.send(msg.encode())

def listen():
    while True:
        client, address = server_socket.accept()
        client_list.append(client)
        t1 = threading.Thread(target = delivered_message, args=(client, address))
        t1.start()


portNo = int(input("Enter port number: "))
server_socket = s.socket(s.AF_INET, s.SOCK_STREAM)
server_socket.bind(('localhost', portNo))
server_socket.listen(5)
print('Server Up and Running')

print("Enter 'Quit' to terminate the Server :")

tmain = threading.Thread(target=listen)
tmain.start()

while True:
    pass
