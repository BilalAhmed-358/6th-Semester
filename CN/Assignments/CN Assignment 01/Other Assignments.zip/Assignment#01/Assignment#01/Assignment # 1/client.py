from tkinter import *
import tkinter as tk
import socket as c
from time import sleep
import threading

socket_client = c.socket(c.AF_INET, c.SOCK_STREAM)
tx2 = ""
def deliver_message():
    tx2 = T2.get("1.0","end")
    messagelist.insert(tk.END, str("You: " + tx2))
    T2.delete('1.0', tk.END)
    socket_client.send(tx2.encode())
    tx2=""

def delivered_message():
    while True:
        reply = socket_client.recv(1024).decode()
        messagelist.insert(tk.END, str(reply))

tx = ""
def text():
    tx = T.get("1.0","end")
    socket_client.connect(('localhost', int(tx)))
    t1 = threading.Thread(target = delivered_message, )
    t2 = threading.Thread(target = deliver_message, )
    t1.start()
    t2.start()

chat_messenger = Tk()
chat_messenger.title("Chat Messenger By Ashmal & Samad")
chat_messenger.geometry("500x800")
T = Text(chat_messenger, height = 4, width = 25)
l = Label(chat_messenger, text = "Port Number")
l.config(font =("Ariel", 15))
button1 = Button(chat_messenger, text = "Click to connect", command = text)
button2 = Button(chat_messenger, text = "Click to Disconnect", command = chat_messenger.destroy)
l.pack()
T.pack()
button1.pack()
button2.pack()
T2 = Text(chat_messenger, height = 3, width = 25)
T2.pack()
b_send = Button(chat_messenger, text = "Deliver Message", command = lambda: threading.Thread(target = deliver_message).start())
b_send.pack()
scrollbar = tk.Scrollbar(chat_messenger)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
messagelist = tk.Listbox(chat_messenger, yscrollcommand = scrollbar.set, width = 120, height = 40)
messagelist.pack()
scrollbar.config(command = messagelist.yview)
tk.mainloop()
