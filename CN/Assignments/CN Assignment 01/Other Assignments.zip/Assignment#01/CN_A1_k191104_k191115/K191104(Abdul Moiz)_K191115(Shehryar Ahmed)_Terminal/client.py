# Import socket module
import socket
import threading




def input_thread(c):
    a = True
    while a:
        send_message= input("Send your message: ")
        print('\n')
        if send_message == 'exit':
            #send_message.encode()
            a=False
            c.send(send_message.encode())
            break
        else:
            #send_message.encode()
            c.send(send_message.encode())


def output_thread(c):
    a = True
    while a:
        rec_message = c.recv(1024).decode()
        # rec_message.decode()
        print('Reply: '+rec_message, end='\n')
        if rec_message == 'exit':
            a=False
            break


if __name__ == '__main__':

    port = input('Enter Port ')
    ip = input ('Enter Ip ')

    port = int(port)
    ip = str(ip)   
    # port = 12345
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    s.connect((ip, port))
    print('connected to the server with port %s'%port)

    print('starting')

    #creating input and output threads
    i_thread = threading.Thread(target=input_thread,args=(s,))
    o_thread = threading.Thread(target=output_thread,args=(s,))	
			
    i_thread.start()
    o_thread.start()

    
    i_thread.join()
    o_thread.join()
    print('Exited')
    s.close()
	
