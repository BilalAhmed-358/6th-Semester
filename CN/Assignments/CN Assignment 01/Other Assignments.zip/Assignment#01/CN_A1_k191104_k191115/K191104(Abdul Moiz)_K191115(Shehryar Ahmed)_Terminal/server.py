import socket
import threading


def input_thread(c):
    a= True
    while a:
        send_message= input("Send your message: ")
        print('\n')
        if send_message == 'exit':
            c.send(send_message.encode())
            a=False
            break
        else:
            # send_message.encode()
            c.send(send_message.encode())


def output_thread(c):
    a=True
    while a:
        rec_message = c.recv(1024).decode()
        # rec_message.decode()
        print('Reply: '+rec_message, end='\n')
        if rec_message == 'exit':
            a=False
            break
    


if __name__ == '__main__':
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)		
    print ("Socket successfully created")

    port = input('Enter Port ')

    port = int(port)
    # port = 12345		

    # Next bind to the port
    # we have not typed any ip in the ip field
    # instead we have inputted an empty string
    # this makes the server listen to requests
    # coming from other computers on the network
    s.bind(('', port))		
    print ("socket binded to %s" %(port))

    # put the socket into listening mode
    s.listen(1)	
    print ("socket is listening")		

    # a forever loop until we interrupt it or
    # an error occurs


    print('starting')
    c, addr = s.accept()
    print ('Got connection from', addr )


    i_thread = threading.Thread(target=input_thread,args=(c,))
    o_thread = threading.Thread(target=output_thread,args=(c,))	


    i_thread.start()
    o_thread.start()


    i_thread.join()
    o_thread.join()
    c.close()
    # Establish connection with client.
    #  print('Enter your message')
    #  string = input()
    #  string_utf= string.encode()

    print('Closed')
