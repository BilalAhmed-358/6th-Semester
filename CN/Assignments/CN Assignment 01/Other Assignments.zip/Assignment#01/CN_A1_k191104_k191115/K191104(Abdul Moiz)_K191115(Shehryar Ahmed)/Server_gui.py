import tkinter as tk
import tkinter.font as tkFont
import socket
import threading

message = 'Message'
connection = 'connect?'



class App:

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def __init__(self, root):
        global message
        global connection
        # setting title
        root.title("Server")
        # setting window size
        width = 600
        height = 500
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height,
                                    (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        GLabel_500 = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        GLabel_500["font"] = ft
        GLabel_500["fg"] = "#ffffff"
        GLabel_500["justify"] = "center"
        GLabel_500["text"] = "Port"
        GLabel_500.place(x=30, y=20, width=70, height=25)
        Port_Entry = tk.Entry(root)

        Port_Entry["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times', size=10)
        Port_Entry["font"] = ft
        Port_Entry["fg"] = "#ffffff"
        Port_Entry["justify"] = "left"
        Port_Entry.place(x=170, y=20, width=70, height=25)

        Send_Entry = tk.Entry(root)
        Send_Entry["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times', size=10)
        Send_Entry["font"] = ft
        Send_Entry["fg"] = "#ffffff"
        Send_Entry["justify"] = "center"
        # Send_Entry["text"] = "Entry"
        Send_Entry.place(x=40, y=190, width=70, height=25)

        Connect_Button = tk.Button(root, command=(
            lambda e=Port_Entry:  self.Connect_Button_command(e)))
        Connect_Button["bg"] = "#f0f0f0"
        ft = tkFont.Font(family='Times', size=10)
        Connect_Button["font"] = ft
        Connect_Button["fg"] = "#000000"
        Connect_Button["justify"] = "center"
        Connect_Button["text"] = "Connect"
        # Connect_Button["command"] = self.Connect_Button_command
        Connect_Button.place(x=280, y=20, width=70, height=25)

        Send_Button = tk.Button(root, command=(
            lambda data=Send_Entry: self.Send_Button_Command(data)))
        Send_Button["bg"] = "#f0f0f0"
        ft = tkFont.Font(family='Times', size=10)
        Send_Button["font"] = ft
        Send_Button["fg"] = "#000000"
        Send_Button["justify"] = "center"
        Send_Button["text"] = "Send"
        Send_Button.place(x=200, y=190, width=70, height=25)
        #Send_Button["command"] = self.Send_Button_Command

        Connection_Label = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        Connection_Label["font"] = ft
        Connection_Label["fg"] = "#ffffff"
        Connection_Label["justify"] = "center"
        Connection_Label["text"] = connection
        Connection_Label.place(x=170, y=70, width=70, height=25)

        Message_label = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        Message_label["font"] = ft
        Message_label["fg"] = "#ffffff"
        Message_label["justify"] = "center"
        Message_label["text"] = message
        Message_label.place(x=40, y=130, width=70, height=25)



    def Connect_Button_command(self, p):

        global message
        global connection
        if connection != 'Connected':
            port = (int(p.get()))
            print(p)

            print("port", port)

            self.s.bind(('', port))
            print('connected to the server with port %s' % port)

            connection = 'Connected to Port and Listening'

            self.s.listen(1)
            print("socket is listening")

            c, addr = self.s.accept()
            print('Got connection from', addr)
            connection = 'Connected'
        else:
            self.rec_message()

        # self.s.close()
        # connection = 'Not Connected!'

    def Send_Button_Command(self, d):
        global connection

        data = (str(d.get()))

        print(data)
        print(data)
        o_thread = threading.Thread(target=self.output_thread,args=(data,))
            #self.s.close()
        o_thread.start()
        
    def output_thread(self,data):
        while True:
            self.s.send(data.encode())
            break

    def rec_message(self):
        global message
        global connection

        rec_message = self.s.recv(1024).decode()
        message = rec_message
        print(rec_message)
        if rec_message == 'exit':
            connection = 'Disconnected'
            self.s.close()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
