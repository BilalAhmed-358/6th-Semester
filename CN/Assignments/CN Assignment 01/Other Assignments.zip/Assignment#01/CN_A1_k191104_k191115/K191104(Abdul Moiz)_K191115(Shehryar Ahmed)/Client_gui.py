import tkinter as tk
import tkinter.font as tkFont
import socket
import threading

message = 'Message'
connection = 'connect?'



class App:

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def __init__(self, root):
        global message
        global connection
        # setting title
        root.title("Client Side")
        # setting window size
        width = 600
        height = 500
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height,
                                    (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        Port_Entry = tk.Entry(root)
        Port_Entry["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times', size=10)
        Port_Entry["font"] = ft
        Port_Entry["fg"] = "#ffffff"
        Port_Entry["justify"] = "center"
        # Port_Entry["text"] = "Entry"
        Port_Entry.place(x=140, y=40, width=70, height=25)

        Ip_Entry = tk.Entry(root)
        Ip_Entry["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times', size=10)
        Ip_Entry["font"] = ft
        Ip_Entry["fg"] = "#ffffff"
        Ip_Entry["justify"] = "center"
        # Ip_Entry["text"] = "Entry"
        Ip_Entry.place(x=140, y=110, width=70, height=25)

        ConnectButton = tk.Button(root,
                                  command=(lambda p=Port_Entry,
                                           ip=Ip_Entry: self.ConnectButton_command(p, ip)))

        ConnectButton["bg"] = "#f0f0f0"
        ft = tkFont.Font(family='Times', size=10)
        ConnectButton["font"] = ft
        ConnectButton["fg"] = "#000000"
        ConnectButton["justify"] = "center"
        ConnectButton["text"] = 'Connect'
        ConnectButton.place(x=330, y=70, width=70, height=25)
        # ConnectButton["command"] = self.ConnectButton_command

        GLabel_0 = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        GLabel_0["font"] = ft
        GLabel_0["fg"] = "#ffffff"
        GLabel_0["justify"] = "center"
        GLabel_0["text"] = connection
        GLabel_0.place(x=330, y=110, width=70, height=25)

        Send_Entry = tk.Entry(root)
        Send_Entry["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times', size=10)
        Send_Entry["font"] = ft
        Send_Entry["fg"] = "#ffffff"
        Send_Entry["justify"] = "center"
        # Send_Entry["text"] = ""
        Send_Entry.place(x=30, y=350, width=70, height=25)

        Port_label = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        Port_label["font"] = ft
        Port_label["fg"] = "#ffffff"
        Port_label["justify"] = "center"
        Port_label["text"] = "Port"
        Port_label.place(x=30, y=40, width=70, height=25)

        GLabel_700 = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        GLabel_700["font"] = ft
        GLabel_700["fg"] = "#ffffff"
        GLabel_700["justify"] = "center"
        GLabel_700["text"] = message
        GLabel_700.place(x=30, y=270, width=70, height=25)

        GLabel_800 = tk.Label(root)
        ft = tkFont.Font(family='Times', size=10)
        GLabel_800["font"] = ft
        GLabel_800["fg"] = "#ffffff"
        GLabel_800["justify"] = "center"
        GLabel_800["text"] = "IP"
        GLabel_800.place(x=30, y=110, width=70, height=25)

        Send_Button = tk.Button(root, command=(
            lambda data=Send_Entry: self.Send_Button_Command(data)))
        Send_Button["bg"] = "#f0f0f0"
        ft = tkFont.Font(family='Times', size=10)
        Send_Button["font"] = ft
        Send_Button["fg"] = "#000000"
        Send_Button["justify"] = "center"
        Send_Button["text"] = "Send"
        Send_Button.place(x=200, y=190, width=70, height=25)
        #Send_Button["command"] = self.Send_Button_Command

    def ConnectButton_command(self, p, IP):
        global connection
        global message

        port = (int(p.get()))
        ip = (str(IP.get()))
        print(port)
        print(ip)

        if connection != 'Connected':

            connection = 'Connecting'
            self.s.connect((ip, port))
            print('connected to the server with port %s' % port)
            connection = 'Connected'
            print('starting')
            message = 'Send Your Message'
        else:
            self.rec_message()


        # self.s.close()
        connection = 'Not Connected!'

    def Send_Button_Command(self, d):

        	

        global connection

        data = (str(d.get()))

        print(data)
        o_thread = threading.Thread(target=self.output_thread,args=(data,))
            #self.s.close()
        o_thread.start()
    
    def output_thread(self,data):
        while True:
            self.s.send(data.encode())
            break

    def rec_message(self):
        global message
        global connection

        rec_message = self.s.recv(1024).decode()
        message = rec_message
        if rec_message == 'exit':
            connection = 'Disconnected'
            self.s.close()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
